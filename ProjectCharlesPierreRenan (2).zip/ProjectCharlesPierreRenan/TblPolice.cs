﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class TblPolice
    {
        public TblPolice()
        {
            TblIncident1s = new HashSet<TblIncident1>();
        }

        public int Policeid { get; set; }
        public string? Pname { get; set; }

        public virtual ICollection<TblIncident1> TblIncident1s { get; set; }
    }
}
