﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class Student
    {
        public int StudentId { get; set; }
        public string? FName { get; set; }
        public string? LName { get; set; }
        public DateTime? Dob { get; set; }
        public string? Gender { get; set; }
        public string? Major { get; set; }
        public int? CarId { get; set; }

        public virtual Car? Car { get; set; }
    }
}
