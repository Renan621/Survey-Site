﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class PublicSafety
    {
        public int PSafeId { get; set; }
        public string? PGender { get; set; }
        public string? Badge { get; set; }
        public string? PName { get; set; }
    }
}
