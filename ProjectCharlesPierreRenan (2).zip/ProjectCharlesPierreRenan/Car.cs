﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class Car
    {
        public Car()
        {
            Faculties = new HashSet<Faculty>();
            Students = new HashSet<Student>();
            Tickets = new HashSet<Ticket>();
        }

        public string? Make { get; set; }
        public string? Model { get; set; }
        public string? Color { get; set; }
        public string? LicensePlate { get; set; }
        public int? CarYear { get; set; }
        public int CarId { get; set; }

        public virtual ICollection<Faculty> Faculties { get; set; }
        public virtual ICollection<Student> Students { get; set; }
        public virtual ICollection<Ticket> Tickets { get; set; }
    }
}
