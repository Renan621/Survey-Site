﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class Ticket
    {
        public int TicketId { get; set; }
        public DateTime? IncidentDate { get; set; }
        public int? StudentId { get; set; }
        public int? FacultyId { get; set; }
        public int? PSafeId { get; set; }
        public string? Comments { get; set; }
        public int? CarId { get; set; }

        public virtual Car? Car { get; set; }
    }
}
