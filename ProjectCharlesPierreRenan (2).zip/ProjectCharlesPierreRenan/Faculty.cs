﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class Faculty
    {
        public int FacultyId { get; set; }
        public string? FacName { get; set; }
        public string? FacGender { get; set; }
        public DateTime? HireDate { get; set; }
        public int? CarId { get; set; }
        public decimal? Salary { get; set; }

        public virtual Car? Car { get; set; }
    }
}
