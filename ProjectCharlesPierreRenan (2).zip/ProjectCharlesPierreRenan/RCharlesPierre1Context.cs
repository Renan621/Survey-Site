﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

namespace ProjectCharlesPierreRenan
{
    public partial class RCharlesPierre1Context : DbContext
    {


        public RCharlesPierre1Context(DbContextOptions<RCharlesPierre1Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Car> Cars { get; set; } = null!;
        public virtual DbSet<Faculty> Faculties { get; set; } = null!;
        public virtual DbSet<PublicSafety> PublicSafeties { get; set; } = null!;
        public virtual DbSet<Student> Students { get; set; } = null!;
        public virtual DbSet<Table> Tables { get; set; } = null!;
        public virtual DbSet<TblCar> TblCars { get; set; } = null!;
        public virtual DbSet<TblDriver> TblDrivers { get; set; } = null!;
        public virtual DbSet<TblFaculty> TblFaculties { get; set; } = null!;
        public virtual DbSet<TblFavAnimal> TblFavAnimals { get; set; } = null!;
        public virtual DbSet<TblFavFood> TblFavFoods { get; set; } = null!;
        public virtual DbSet<TblIncident> TblIncidents { get; set; } = null!;
        public virtual DbSet<TblIncident1> TblIncidents1 { get; set; } = null!;
        public virtual DbSet<TblPolice> TblPolices { get; set; } = null!;
        public virtual DbSet<TblPublicSafety> TblPublicSafeties { get; set; } = null!;
        public virtual DbSet<TblStudent> TblStudents { get; set; } = null!;
        public virtual DbSet<TblUser> TblUsers { get; set; } = null!;
        public virtual DbSet<TblViolation> TblViolations { get; set; } = null!;
        public virtual DbSet<Ticket> Tickets { get; set; } = null!;

        public IConfiguration myconfig { get; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=10.22.13.242; Initial Catalog= RCharlesPierre1 ; User Id = RCharlesPierre1; password= H703004412; TrustServerCertificate=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Car>(entity =>
            {
                entity.Property(e => e.CarId).HasColumnName("carId");

                entity.Property(e => e.CarYear).HasColumnName("carYear");

                entity.Property(e => e.Color)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("color");

                entity.Property(e => e.LicensePlate)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("licensePlate");

                entity.Property(e => e.Make)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("make");

                entity.Property(e => e.Model)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("model");
            });

            modelBuilder.Entity<Faculty>(entity =>
            {
                entity.ToTable("Faculty");

                entity.Property(e => e.FacultyId).HasColumnName("facultyId");

                entity.Property(e => e.CarId).HasColumnName("carId");

                entity.Property(e => e.FacGender)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("facGender");

                entity.Property(e => e.FacName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("facName");

                entity.Property(e => e.HireDate)
                    .HasColumnType("date")
                    .HasColumnName("hireDate");

                entity.Property(e => e.Salary)
                    .HasColumnType("money")
                    .HasColumnName("salary");

                entity.HasOne(d => d.Car)
                    .WithMany(p => p.Faculties)
                    .HasForeignKey(d => d.CarId)
                    .HasConstraintName("FK__Faculty__carId__33D4B598");
            });

            modelBuilder.Entity<PublicSafety>(entity =>
            {
                entity.HasKey(e => e.PSafeId)
                    .HasName("PK__Public_S__775D52786FB5E964");

                entity.ToTable("Public_Safety");

                entity.Property(e => e.PSafeId).HasColumnName("pSafeId");

                entity.Property(e => e.Badge)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("badge");

                entity.Property(e => e.PGender)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("pGender");

                entity.Property(e => e.PName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("pName");
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.ToTable("Student");

                entity.Property(e => e.StudentId).HasColumnName("studentId");

                entity.Property(e => e.CarId).HasColumnName("carId");

                entity.Property(e => e.Dob).HasColumnType("date");

                entity.Property(e => e.FName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("fName");

                entity.Property(e => e.Gender)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("gender");

                entity.Property(e => e.LName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lName");

                entity.Property(e => e.Major)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("major");

                entity.HasOne(d => d.Car)
                    .WithMany(p => p.Students)
                    .HasForeignKey(d => d.CarId)
                    .HasConstraintName("FK__Student__carId__36B12243");
            });

            modelBuilder.Entity<Table>(entity =>
            {
                entity.ToTable("Table");

                entity.Property(e => e.Fname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("fname");

                entity.Property(e => e.Lname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lname");
            });

            modelBuilder.Entity<TblCar>(entity =>
            {
                entity.HasKey(e => e.CarId)
                    .HasName("PK__tblCar__1436F17427828D00");

                entity.ToTable("tblCar");

                entity.Property(e => e.CarId).HasColumnName("carId");

                entity.Property(e => e.CarYear)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("carYear")
                    .IsFixedLength();

                entity.Property(e => e.Color)
                    .HasMaxLength(20)
                    .HasColumnName("color");

                entity.Property(e => e.Cost).HasColumnName("cost");

                entity.Property(e => e.LicensePlate)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("licensePlate");

                entity.Property(e => e.Make)
                    .HasMaxLength(20)
                    .HasColumnName("make");

                entity.Property(e => e.Model)
                    .HasMaxLength(20)
                    .HasColumnName("model");
            });

            modelBuilder.Entity<TblDriver>(entity =>
            {
                entity.HasKey(e => e.Driverid)
                    .HasName("PK__tblDrive__F152282A1B76AFED");

                entity.ToTable("tblDriver");

                entity.Property(e => e.Driverid).HasColumnName("driverid");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("address");

                entity.Property(e => e.City)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("city");

                entity.Property(e => e.Dname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("dname");

                entity.Property(e => e.State)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("state");

                entity.Property(e => e.Zip).HasColumnName("zip");
            });

            modelBuilder.Entity<TblFaculty>(entity =>
            {
                entity.HasKey(e => e.FacultyId)
                    .HasName("PK__tblFacul__DBBF6FD1CC0EFFDD");

                entity.ToTable("tblFaculty");

                entity.Property(e => e.FacultyId).HasColumnName("facultyID");

                entity.Property(e => e.CarId).HasColumnName("carID");

                entity.Property(e => e.FacGender)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("facGender")
                    .IsFixedLength();

                entity.Property(e => e.FacName)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("facName");

                entity.Property(e => e.HireDate)
                    .HasColumnType("date")
                    .HasColumnName("hireDate");

                entity.Property(e => e.Salary).HasColumnName("salary");

                entity.HasOne(d => d.Car)
                    .WithMany(p => p.TblFaculties)
                    .HasForeignKey(d => d.CarId)
                    .HasConstraintName("FK__tblFacult__carID__4AB81AF0");
            });

            modelBuilder.Entity<TblFavAnimal>(entity =>
            {
                entity.HasKey(e => e.AnimalId)
                    .HasName("PK__tblFavAn__687456319B675AB7");

                entity.ToTable("tblFavAnimals");

                entity.Property(e => e.AnimalId).HasColumnName("animalID");

                entity.Property(e => e.FlightAnimal)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("flight_animal");

                entity.Property(e => e.LandAnimal)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("land_animal");

                entity.Property(e => e.SeaAnimal)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("sea_animal");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TblFavAnimals)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__tblFavAni__user___6C190EBB");
            });

            modelBuilder.Entity<TblFavFood>(entity =>
            {
                entity.HasKey(e => e.FoodId)
                    .HasName("PK__tblFavFo__77EAEA19CD9EB876");

                entity.ToTable("tblFavFoods");

                entity.Property(e => e.FoodId).HasColumnName("foodID");

                entity.Property(e => e.Breakfast)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("breakfast");

                entity.Property(e => e.Dinner)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("dinner");

                entity.Property(e => e.Lunch)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lunch");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TblFavFoods)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__tblFavFoo__user___6E01572D");
            });

            modelBuilder.Entity<TblIncident>(entity =>
            {
                entity.HasKey(e => e.IncidentId)
                    .HasName("PK__tblIncid__06A5D761807E5043");

                entity.ToTable("tblIncident");

                entity.Property(e => e.IncidentId).HasColumnName("incidentID");

                entity.Property(e => e.Carid).HasColumnName("carid");

                entity.Property(e => e.Comments)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.Facultyid).HasColumnName("facultyid");

                entity.Property(e => e.IncidentDate)
                    .HasColumnType("date")
                    .HasColumnName("incidentDate");

                entity.Property(e => e.PsafetyId).HasColumnName("psafetyId");

                entity.Property(e => e.StudentId).HasColumnName("studentID");

                entity.HasOne(d => d.Car)
                    .WithMany(p => p.TblIncidents)
                    .HasForeignKey(d => d.Carid)
                    .HasConstraintName("FK__tblIncide__carid__5535A963");

                entity.HasOne(d => d.Faculty)
                    .WithMany(p => p.TblIncidents)
                    .HasForeignKey(d => d.Facultyid)
                    .HasConstraintName("FK__tblIncide__facul__534D60F1");

                entity.HasOne(d => d.Psafety)
                    .WithMany(p => p.TblIncidents)
                    .HasForeignKey(d => d.PsafetyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tblIncide__psafe__5441852A");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.TblIncidents)
                    .HasForeignKey(d => d.StudentId)
                    .HasConstraintName("FK__tblIncide__stude__52593CB8");
            });

            modelBuilder.Entity<TblIncident1>(entity =>
            {
                entity.HasKey(e => e.Incidentid)
                    .HasName("PK__tblIncid__06A2C399B9BEBCE3");

                entity.ToTable("tblIncidents");

                entity.Property(e => e.Incidentid).HasColumnName("incidentid");

                entity.Property(e => e.Driverid).HasColumnName("driverid");

                entity.Property(e => e.Incidentdate)
                    .HasColumnType("date")
                    .HasColumnName("incidentdate");

                entity.Property(e => e.Policeid).HasColumnName("policeid");

                entity.Property(e => e.Violationid).HasColumnName("violationid");

                entity.HasOne(d => d.Driver)
                    .WithMany(p => p.TblIncident1s)
                    .HasForeignKey(d => d.Driverid)
                    .HasConstraintName("FK__tblIncide__drive__6477ECF3");

                entity.HasOne(d => d.Police)
                    .WithMany(p => p.TblIncident1s)
                    .HasForeignKey(d => d.Policeid)
                    .HasConstraintName("FK__tblIncide__polic__6383C8BA");

                entity.HasOne(d => d.Violation)
                    .WithMany(p => p.TblIncident1s)
                    .HasForeignKey(d => d.Violationid)
                    .HasConstraintName("FK__tblIncide__viola__628FA481");
            });

            modelBuilder.Entity<TblPolice>(entity =>
            {
                entity.HasKey(e => e.Policeid)
                    .HasName("PK__tblPolic__F20332AA0CBD40BF");

                entity.ToTable("tblPolice");

                entity.Property(e => e.Policeid).HasColumnName("policeid");

                entity.Property(e => e.Pname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("pname");
            });

            modelBuilder.Entity<TblPublicSafety>(entity =>
            {
                entity.HasKey(e => e.PsafetyId)
                    .HasName("PK__tblPubli__9192AD25F33A41EF");

                entity.ToTable("tblPublicSafety");

                entity.Property(e => e.PsafetyId).HasColumnName("psafetyID");

                entity.Property(e => e.Badge)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("badge");

                entity.Property(e => e.PGender)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("pGender")
                    .IsFixedLength();

                entity.Property(e => e.PName)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("pName");
            });

            modelBuilder.Entity<TblStudent>(entity =>
            {
                entity.HasKey(e => e.StudentId)
                    .HasName("PK__tblStude__4D11D65CBC1C8594");

                entity.ToTable("tblStudent");

                entity.Property(e => e.StudentId).HasColumnName("studentID");

                entity.Property(e => e.CarId).HasColumnName("carID");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("DOB");

                entity.Property(e => e.FName)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("fName");

                entity.Property(e => e.Gender)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("gender")
                    .IsFixedLength();

                entity.Property(e => e.LName)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("lName");

                entity.Property(e => e.Major)
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasColumnName("major");

                entity.HasOne(d => d.Car)
                    .WithMany(p => p.TblStudents)
                    .HasForeignKey(d => d.CarId)
                    .HasConstraintName("FK__tblStuden__carID__4F7CD00D");
            });

            modelBuilder.Entity<TblUser>(entity =>
            {
                entity.ToTable("tblUser");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Fname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("fname");

                entity.Property(e => e.Lname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("lname");
            });

            modelBuilder.Entity<TblViolation>(entity =>
            {
                entity.HasKey(e => e.Violationid)
                    .HasName("PK__tblViola__6897F7D8FEDE82CD");

                entity.ToTable("tblViolation");

                entity.Property(e => e.Violationid).HasColumnName("violationid");

                entity.Property(e => e.Fine).HasColumnName("fine");

                entity.Property(e => e.Violation)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("violation");
            });

            modelBuilder.Entity<Ticket>(entity =>
            {
                entity.Property(e => e.TicketId).HasColumnName("ticketId");

                entity.Property(e => e.CarId).HasColumnName("carId");

                entity.Property(e => e.Comments)
                    .HasMaxLength(75)
                    .IsUnicode(false)
                    .HasColumnName("comments");

                entity.Property(e => e.FacultyId).HasColumnName("facultyId");

                entity.Property(e => e.IncidentDate)
                    .HasColumnType("date")
                    .HasColumnName("incidentDate");

                entity.Property(e => e.PSafeId).HasColumnName("pSafeId");

                entity.Property(e => e.StudentId).HasColumnName("studentId");

                entity.HasOne(d => d.Car)
                    .WithMany(p => p.Tickets)
                    .HasForeignKey(d => d.CarId)
                    .HasConstraintName("FK__Tickets__carId__3B75D760");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
