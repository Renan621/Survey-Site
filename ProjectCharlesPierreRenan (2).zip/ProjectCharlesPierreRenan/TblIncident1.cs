﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class TblIncident1
    {
        public int Incidentid { get; set; }
        public DateTime? Incidentdate { get; set; }
        public int? Violationid { get; set; }
        public int? Policeid { get; set; }
        public int? Driverid { get; set; }

        public virtual TblDriver? Driver { get; set; }
        public virtual TblPolice? Police { get; set; }
        public virtual TblViolation? Violation { get; set; }
    }
}
