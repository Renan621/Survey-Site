using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectCharlesPierreRenan.Pages
{
    public class YourSurveyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
