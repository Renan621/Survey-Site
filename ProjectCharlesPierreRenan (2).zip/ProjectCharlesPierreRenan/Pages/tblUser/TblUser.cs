﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class TblUser
    {
        public TblUser()
        {
            TblFavAnimals = new HashSet<TblFavAnimal>();
            TblFavFoods = new HashSet<TblFavFood>();
        }

        public int Id { get; set; }
        public string Fname { get; set; } = null!;
        public string Lname { get; set; } = null!;

        public virtual ICollection<TblFavAnimal> TblFavAnimals { get; set; }
        public virtual ICollection<TblFavFood> TblFavFoods { get; set; }
    }
}
