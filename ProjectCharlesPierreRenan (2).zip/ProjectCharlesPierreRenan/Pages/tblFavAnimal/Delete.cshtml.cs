﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectCharlesPierreRenan;

namespace ProjectCharlesPierreRenan.Pages.tblFavAnimal
{
    public class DeleteModel : PageModel
    {
        private readonly ProjectCharlesPierreRenan.RCharlesPierre1Context _context;

        public DeleteModel(ProjectCharlesPierreRenan.RCharlesPierre1Context context)
        {
            _context = context;
        }

        [BindProperty]
      public TblFavAnimal TblFavAnimal { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.TblFavAnimals == null)
            {
                return NotFound();
            }

            var tblfavanimal = await _context.TblFavAnimals.FirstOrDefaultAsync(m => m.AnimalId == id);

            if (tblfavanimal == null)
            {
                return NotFound();
            }
            else 
            {
                TblFavAnimal = tblfavanimal;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.TblFavAnimals == null)
            {
                return NotFound();
            }
            var tblfavanimal = await _context.TblFavAnimals.FindAsync(id);

            if (tblfavanimal != null)
            {
                TblFavAnimal = tblfavanimal;
                _context.TblFavAnimals.Remove(TblFavAnimal);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
