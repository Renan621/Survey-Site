﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ProjectCharlesPierreRenan;

namespace ProjectCharlesPierreRenan.Pages.tblFavAnimal
{
    public class CreateModel : PageModel
    {
        private readonly ProjectCharlesPierreRenan.RCharlesPierre1Context _context;

        public CreateModel(ProjectCharlesPierreRenan.RCharlesPierre1Context context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["UserId"] = new SelectList(_context.TblUsers, "Id", "Id");
            return Page();
        }

        [BindProperty]
        public TblFavAnimal TblFavAnimal { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.TblFavAnimals == null || TblFavAnimal == null)
            {
                return Page();
            }

            _context.TblFavAnimals.Add(TblFavAnimal);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
