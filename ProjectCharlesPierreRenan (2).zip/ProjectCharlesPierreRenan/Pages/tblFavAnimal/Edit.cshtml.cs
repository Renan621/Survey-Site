﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjectCharlesPierreRenan;

namespace ProjectCharlesPierreRenan.Pages.tblFavAnimal
{
    public class EditModel : PageModel
    {
        private readonly ProjectCharlesPierreRenan.RCharlesPierre1Context _context;

        public EditModel(ProjectCharlesPierreRenan.RCharlesPierre1Context context)
        {
            _context = context;
        }

        [BindProperty]
        public TblFavAnimal TblFavAnimal { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.TblFavAnimals == null)
            {
                return NotFound();
            }

            var tblfavanimal =  await _context.TblFavAnimals.FirstOrDefaultAsync(m => m.AnimalId == id);
            if (tblfavanimal == null)
            {
                return NotFound();
            }
            TblFavAnimal = tblfavanimal;
           ViewData["UserId"] = new SelectList(_context.TblUsers, "Id", "Id");
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(TblFavAnimal).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TblFavAnimalExists(TblFavAnimal.AnimalId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool TblFavAnimalExists(int id)
        {
          return (_context.TblFavAnimals?.Any(e => e.AnimalId == id)).GetValueOrDefault();
        }
    }
}
