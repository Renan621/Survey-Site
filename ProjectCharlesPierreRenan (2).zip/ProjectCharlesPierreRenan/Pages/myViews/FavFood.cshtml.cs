using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace ProjectCharlesPierreRenan.Pages.MyViews
{
    public class FavFoodModel : PageModel
    {
        private readonly ProjectCharlesPierreRenan.RCharlesPierre1Context _context;
        public FavFoodModel(ProjectCharlesPierreRenan.RCharlesPierre1Context context)
        {
            _context = context;
        }
        public IList<TblFavFood> TblFavFood { get; set; }
        public async Task OnGetAsync()
        {
            TblFavFood = await _context.TblFavFoods.ToListAsync();
        }
    }
}
