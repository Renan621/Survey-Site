using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectCharlesPierreRenan.Pages.myViews
{
    public class UsersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
