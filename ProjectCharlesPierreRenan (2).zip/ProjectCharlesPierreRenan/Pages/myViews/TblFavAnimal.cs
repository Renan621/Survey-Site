﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ProjectCharlesPierreRenan
{
    public partial class TblFavAnimal
    {
       [Display (Name = "Favorite Land Animal")]
        public string? LandAnimal { get; set; }

        [Display(Name = "Favorite Flying Animal")]
        public string? FlightAnimal { get; set; }

        [Display (Name = "Favorite Sea Animal")]
        public string? SeaAnimal { get; set; }

        [Display (Name = "User ID")]
        public int? UserId { get; set; }

        [Display (Name = "Quiz ID")]
        public int AnimalId { get; set; }

        public virtual TblUser? User { get; set; }

    }
}
