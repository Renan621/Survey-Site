using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace ProjectCharlesPierreRenan.Pages.MyViews
{
    public class FavAnimalModel : PageModel { 
        private readonly ProjectCharlesPierreRenan.RCharlesPierre1Context _context;
        public FavAnimalModel(ProjectCharlesPierreRenan.RCharlesPierre1Context context)
        {
            _context = context;
        }
        public IList<TblFavAnimal> TblFavAnimal { get; set; }
        public async Task OnGetAsync()
        {
            TblFavAnimal = await _context.TblFavAnimals.ToListAsync();
        }
    }
}
