﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProjectCharlesPierreRenan;

namespace ProjectCharlesPierreRenan.Pages.tblFavFood
{
    public class DeleteModel : PageModel
    {
        private readonly ProjectCharlesPierreRenan.RCharlesPierre1Context _context;

        public DeleteModel(ProjectCharlesPierreRenan.RCharlesPierre1Context context)
        {
            _context = context;
        }

        [BindProperty]
      public TblFavFood TblFavFood { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.TblFavFoods == null)
            {
                return NotFound();
            }

            var tblfavfood = await _context.TblFavFoods.FirstOrDefaultAsync(m => m.FoodId == id);

            if (tblfavfood == null)
            {
                return NotFound();
            }
            else 
            {
                TblFavFood = tblfavfood;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.TblFavFoods == null)
            {
                return NotFound();
            }
            var tblfavfood = await _context.TblFavFoods.FindAsync(id);

            if (tblfavfood != null)
            {
                TblFavFood = tblfavfood;
                _context.TblFavFoods.Remove(TblFavFood);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
