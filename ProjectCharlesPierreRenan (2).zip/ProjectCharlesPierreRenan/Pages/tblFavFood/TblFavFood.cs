﻿using System;
using System.Collections.Generic;

namespace ProjectCharlesPierreRenan
{
    public partial class TblFavFood
    {
        public string? Breakfast { get; set; }
        public string? Lunch { get; set; }
        public string? Dinner { get; set; }
        public int? UserId { get; set; }
        public int FoodId { get; set; }

        public virtual TblUser? User { get; set; }
    }
}
